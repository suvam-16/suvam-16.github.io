package com.example.eventtracking;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.text.InputType;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class EventGridActivity extends AppCompatActivity {

    private List<Event> events; // List of events
    private EventGridAdapter adapter; // Adapter for RecyclerView
    private DatabaseHelper dbHelper; // Database Helper

    private int loggedInUserId; // User ID of the logged-in user

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_grid);

        // Initialize DatabaseHelper
        dbHelper = new DatabaseHelper(this);

        // Retrieve logged-in user ID
        SharedPreferences sharedPreferences = getSharedPreferences("EventTrackingPrefs", MODE_PRIVATE);
        loggedInUserId = sharedPreferences.getInt("loggedInUserId", -1);

        if (loggedInUserId == -1) {
            Toast.makeText(this, "No logged-in user found. Please log in again.", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        // Initialize events list
        events = new ArrayList<>();

        // Set up RecyclerView
        RecyclerView recyclerView = findViewById(R.id.event_grid_recycler);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 2)); // Grid with 2 columns
        adapter = new EventGridAdapter(events, this::deleteEvent);
        recyclerView.setAdapter(adapter);

        // Load events from the database
        loadEventsFromDatabase();

        // FloatingActionButton for adding events
        FloatingActionButton addButton = findViewById(R.id.add_event_button);
        addButton.setOnClickListener(v -> showAddEventDialog());

        // FloatingActionButton for SMS notifications
        FloatingActionButton smsButton = findViewById(R.id.sms_button);
        smsButton.setOnClickListener(v -> {
            Intent intent = new Intent(EventGridActivity.this, SMSActivity.class);
            startActivity(intent);
        });
    }

    // Load events for the logged-in user from the database
    private void loadEventsFromDatabase() {
        events.clear();

        // Query database for events of the logged-in user
        Cursor cursor = dbHelper.getEventsForUser(loggedInUserId);
        if (cursor != null) {
            try {
                while (cursor.moveToNext()) {
                    int id = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_EVENT_ID));
                    String name = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_EVENT_NAME));
                    String date = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_EVENT_DATE));
                    events.add(new Event(id, name, date));
                }
            } finally {
                cursor.close();
            }
        }
        adapter.notifyDataSetChanged();
    }

    // Show dialog to add a new event
    private void showAddEventDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Add New Event");

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);

        // Input for event name
        final EditText nameInput = new EditText(this);
        nameInput.setHint("Enter Event Name");
        layout.addView(nameInput);

        // Input for event date
        final EditText dateInput = new EditText(this);
        dateInput.setHint("Select Event Date");
        dateInput.setFocusable(false);
        dateInput.setOnClickListener(v -> showDatePickerDialog(dateInput));
        layout.addView(dateInput);

        builder.setView(layout);

        builder.setPositiveButton("Add", (dialog, which) -> {
            String name = nameInput.getText().toString();
            String date = dateInput.getText().toString();
            if (!name.isEmpty() && !date.isEmpty()) {
                long eventId = dbHelper.addEvent(name, date, loggedInUserId);
                if (eventId != -1) {
                    events.add(new Event((int) eventId, name, date));
                    adapter.notifyItemInserted(events.size() - 1);
                } else {
                    Toast.makeText(this, "Failed to add event. Try again.", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, "Fields cannot be empty", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());
        builder.show();
    }

    // Show date picker dialog for event date
    private void showDatePickerDialog(EditText dateInput) {
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        new android.app.DatePickerDialog(this,
                (view, year1, month1, day1) -> dateInput.setText(year1 + "-" + (month1 + 1) + "-" + day1),
                year, month, day).show();
    }

    // Delete event from the database and update the grid
    private void deleteEvent(int position) {
        Event event = events.get(position);
        int rowsAffected = dbHelper.deleteEvent(event.getId());
        if (rowsAffected > 0) {
            events.remove(position);
            adapter.notifyItemRemoved(position);
        } else {
            Toast.makeText(this, "Failed to delete event. Try again.", Toast.LENGTH_SHORT).show();
        }
    }
}
