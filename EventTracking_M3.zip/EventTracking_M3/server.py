from flask import Flask, request, jsonify
import pymysql

app = Flask(__name__)

# MySQL configuration
db_config = {
    'host': 'localhost',
    'user': 'root',
    'password': '',  # Add your MySQL password here if needed
    'database': 'eventtracking',
    'cursorclass': pymysql.cursors.Cursor
}

# Helper to connect to MySQL
def get_connection():
    return pymysql.connect(**db_config)

@app.route('/register', methods=['POST'])
def register():
    data = request.get_json()
    username = data['username']
    password = data['password']

    conn = get_connection()
    cursor = conn.cursor()

    try:
        cursor.execute("INSERT INTO users (username, password) VALUES (%s, %s)", (username, password))
        conn.commit()
        return jsonify({"message": "User registered successfully"}), 201
    except:
        return jsonify({"error": "Username already exists"}), 409
    finally:
        cursor.close()
        conn.close()

@app.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    username = data['username']
    password = data['password']

    print(f"Login attempt: {username} / {password}")  # Debug print

    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT id FROM users WHERE username = %s AND password = %s", (username, password))
    user = cursor.fetchone()

    cursor.close()
    conn.close()

    if user:
        return jsonify({"message": "Login successful", "user_id": user[0]})
    else:
        return jsonify({"error": "Invalid credentials"}), 401

@app.route('/events/<int:user_id>', methods=['GET'])
def get_events(user_id):
    sort_by = request.args.get('sort', 'date')  # default to date

    if sort_by == 'name':
        query = "SELECT * FROM events WHERE user_id = %s ORDER BY event_name ASC"
    else:
        query = "SELECT * FROM events WHERE user_id = %s ORDER BY event_date ASC"

    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute(query, (user_id,))
    rows = cursor.fetchall()

    events = []
    for row in rows:
        events.append({
            "event_id": row[0],
            "event_name": row[1],
            "event_date": row[2].strftime("%Y-%m-%d"),
            "event_desc": row[3]
        })

    cursor.close()
    conn.close()
    return jsonify(events)

@app.route('/add_event', methods=['POST'])
def add_event():
    data = request.get_json()
    event_name = data['event_name']
    event_date = data['event_date']
    event_desc = data.get('event_desc', '')
    user_id = data['user_id']

    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("INSERT INTO events (event_name, event_date, event_desc, user_id) VALUES (%s, %s, %s, %s)",
                   (event_name, event_date, event_desc, user_id))
    conn.commit()

    cursor.close()
    conn.close()
    return jsonify({"message": "Event added"}), 201

@app.route('/delete_event/<int:event_id>', methods=['DELETE'])
def delete_event(event_id):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM events WHERE event_id = %s", (event_id,))
    conn.commit()

    cursor.close()
    conn.close()
    return jsonify({"message": "Event deleted"}), 200

@app.route('/', methods=['GET'])
def home():
    return jsonify({"message": "Server is running"})

@app.route('/test', methods=['GET', 'POST'])
def test_route():
    print(f"Received a {request.method} request to /test")
    return jsonify({"message": f"Test route works via {request.method}"})

if __name__ == '__main__':
    app.run(host="0.0.0.0", port=5000, debug=True)
