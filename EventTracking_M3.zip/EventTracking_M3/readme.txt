Event Tracking App — Log

This project is a full-stack Event Tracking App built with:
- Android (Java, Volley library)
- Flask (Python backend API)
- MySQL (via phpMyAdmin using XAMPP)

----------------------
FEATURES
----------------------
- Register/Login via Flask backend
- Add, view, filter, and delete events
- Events stored in MySQL and fetched through API
- Events displayed in a grid layout
- Supports SMS activity (uses native phone features)

----------------------
PREREQUISITES
----------------------
1. Android
- Android Studio 
- Android Emulator or physical device

2. Flask Backend
- Python
- Flask and PyMySQL modules installed 

3. Database
- XAMPP installed
- phpMyAdmin accessible at http://localhost/phpmyadmin

----------------------
STEP-BY-STEP SETUP
----------------------

1. SET UP MYSQL DATABASE
-------------------------
- Launch XAMPP Control Panel
- Start Apache and MySQL
- Open http://localhost/phpmyadmin
- Create a new database named: eventtracking
- Run this SQL script:

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(100) NOT NULL
);

CREATE TABLE events (
    event_id INT AUTO_INCREMENT PRIMARY KEY,
    event_name VARCHAR(100),
    event_date DATE,
    event_desc TEXT,
    user_id INT,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

2. RUN THE FLASK SERVER
-------------------------
- Open terminal
- Navigate to the folder with `server.py`
- Run the server:

python server.py

- Confirm server is running on local IP (e.g., http://192.168.1.71:5000)

3. CONFIGURE ANDROID APP
-------------------------
- Open Android Studio
- Open the EventTracking project
- In EventGridActivity.java, update the BASE_URL to your IP:

private final String BASE_URL = "http://192.168.1.71:5000";

- Run the app on emulator 

----------------------
NOTES
----------------------
- Flask handles API requests for register, login, event CRUD
- Events are stored in MySQL, not SQLite
- App uses the Volley library to send GET/POST/DELETE requests
- API tested using Postman for confirmation


