package com.example.eventtracking;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "event_tracking.db";
    private static final int DATABASE_VERSION = 2; // Bumped version for schema update

    // Table and columns for users
    public static final String TABLE_USERS = "users";
    public static final String COLUMN_USER_ID = "id";
    public static final String COLUMN_USERNAME = "username";
    public static final String COLUMN_PASSWORD = "password";

    // Table and columns for events
    public static final String TABLE_EVENTS = "events";
    public static final String COLUMN_EVENT_ID = "event_id";
    public static final String COLUMN_EVENT_NAME = "event_name";
    public static final String COLUMN_EVENT_DATE = "event_date";
    public static final String COLUMN_EVENT_DESC = "event_desc"; // NEW
    public static final String COLUMN_EVENT_USER_ID = "user_id";

    // SQL to create users table
    private static final String CREATE_USERS_TABLE = "CREATE TABLE " + TABLE_USERS + " (" +
            COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            COLUMN_USERNAME + " TEXT NOT NULL UNIQUE, " +
            COLUMN_PASSWORD + " TEXT NOT NULL)";

    // SQL to create events table
    private static final String CREATE_EVENTS_TABLE = "CREATE TABLE " + TABLE_EVENTS + " (" +
            COLUMN_EVENT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            COLUMN_EVENT_NAME + " TEXT NOT NULL, " +
            COLUMN_EVENT_DATE + " TEXT NOT NULL, " +
            COLUMN_EVENT_DESC + " TEXT, " + // NEW FIELD
            COLUMN_EVENT_USER_ID + " INTEGER NOT NULL, " +
            "FOREIGN KEY(" + COLUMN_EVENT_USER_ID + ") REFERENCES " + TABLE_USERS + "(" + COLUMN_USER_ID + "))";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_USERS_TABLE);
        db.execSQL(CREATE_EVENTS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_EVENTS);
        onCreate(db);
    }

    // Add a new user to the database
    public long addUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_PASSWORD, password);
        return db.insert(TABLE_USERS, null, values);
    }

    // Validate user credentials and return user ID
    public int validateUserAndGetId(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS, new String[]{COLUMN_USER_ID},
                COLUMN_USERNAME + " = ? AND " + COLUMN_PASSWORD + " = ?",
                new String[]{username, password}, null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            int userId = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_USER_ID));
            cursor.close();
            return userId;
        }

        if (cursor != null) {
            cursor.close();
        }
        return -1;
    }

    // Add a new event to the database
    public long addEvent(String eventName, String eventDate, String eventDesc, int userId) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_EVENT_NAME, eventName);
        values.put(COLUMN_EVENT_DATE, eventDate);
        values.put(COLUMN_EVENT_DESC, eventDesc); // NEW VALUE
        values.put(COLUMN_EVENT_USER_ID, userId);
        return db.insert(TABLE_EVENTS, null, values);
    }

    // Get all events for a specific user
    public Cursor getEventsForUser(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(TABLE_EVENTS, null, COLUMN_EVENT_USER_ID + " = ?",
                new String[]{String.valueOf(userId)}, null, null, null);
    }

    // Get events sorted by date for a user (ascending)
    public Cursor getEventsSortedByDate(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_EVENTS +
                        " WHERE " + COLUMN_EVENT_USER_ID + " = ?" +
                        " ORDER BY " + COLUMN_EVENT_DATE + " ASC",
                new String[]{String.valueOf(userId)});
    }

    // Get events sorted alphabetically by event name (case-insensitive)
    public Cursor getEventsSortedByName(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_EVENTS +
                        " WHERE " + COLUMN_EVENT_USER_ID + " = ?" +
                        " ORDER BY " + COLUMN_EVENT_NAME + " COLLATE NOCASE ASC",
                new String[]{String.valueOf(userId)});
    }

    // Delete an event by event ID
    public int deleteEvent(int eventId) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_EVENTS, COLUMN_EVENT_ID + " = ?", new String[]{String.valueOf(eventId)});
    }
}
