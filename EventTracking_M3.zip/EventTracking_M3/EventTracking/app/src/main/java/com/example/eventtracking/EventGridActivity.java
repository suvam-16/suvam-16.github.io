package com.example.eventtracking;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class EventGridActivity extends AppCompatActivity {

    private List<Event> events = new ArrayList<>();
    private List<Event> allEvents = new ArrayList<>();
    private EventGridAdapter adapter;

    private int loggedInUserId;
    private RequestQueue requestQueue;
    private final String BASE_URL = "http://192.168.1.71:5000";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_grid);

        // Get user ID from shared preferences
        SharedPreferences sharedPreferences = getSharedPreferences("EventTrackingPrefs", MODE_PRIVATE);
        loggedInUserId = sharedPreferences.getInt("loggedInUserId", -1);

        if (loggedInUserId == -1) {
            Toast.makeText(this, "User not found. Login again.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        requestQueue = Volley.newRequestQueue(this);

        // Setup RecyclerView and adapter
        RecyclerView recyclerView = findViewById(R.id.event_grid_recycler);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));
        adapter = new EventGridAdapter(events, this::deleteEvent);
        recyclerView.setAdapter(adapter);

        // Setup sort spinner
        Spinner sortSpinner = findViewById(R.id.sort_spinner);
        ArrayAdapter<CharSequence> spinnerAdapter = ArrayAdapter.createFromResource(
                this, R.array.sort_options, android.R.layout.simple_spinner_item);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sortSpinner.setAdapter(spinnerAdapter);

        sortSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                loadEventsFromBackend();
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });

        // Search bar to filter events
        EditText searchInput = findViewById(R.id.search_input);
        searchInput.addTextChangedListener(new TextWatcher() {
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                filterEvents(s.toString().trim());
            }
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void afterTextChanged(Editable s) {}
        });

        // Add Event button
        FloatingActionButton addButton = findViewById(R.id.add_event_button);
        addButton.setOnClickListener(v -> showAddEventDialog());

        // SMS button
        FloatingActionButton smsButton = findViewById(R.id.sms_button);
        smsButton.setOnClickListener(v -> startActivity(new Intent(this, SMSActivity.class)));

        loadEventsFromBackend();
    }

    // Load events from Flask API
    private void loadEventsFromBackend() {
        int sortPosition = ((Spinner) findViewById(R.id.sort_spinner)).getSelectedItemPosition();
        String sortParam = (sortPosition == 1) ? "name" : "date";
        String url = BASE_URL + "/events/" + loggedInUserId + "?sort=" + sortParam;
        JsonArrayRequest request = new JsonArrayRequest(Request.Method.GET, url, null,
                response -> {
                    events.clear();
                    allEvents.clear();
                    try {
                        for (int i = 0; i < response.length(); i++) {
                            JSONObject obj = response.getJSONObject(i);
                            Event event = new Event(
                                    obj.getInt("event_id"),
                                    obj.getString("event_name"),
                                    obj.getString("event_date"),
                                    obj.getString("event_desc")
                            );
                            events.add(event);
                            allEvents.add(event);
                        }
                        adapter.updateList(new ArrayList<>(events));
                    } catch (Exception e) {
                        Toast.makeText(this, "Parse error", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> Toast.makeText(this, "Fetch error", Toast.LENGTH_SHORT).show()
        );
        requestQueue.add(request);
    }

    // Dialog to add event
    private void showAddEventDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Add New Event");

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);

        final EditText nameInput = new EditText(this);
        nameInput.setHint("Enter Event Name");
        layout.addView(nameInput);

        final EditText dateInput = new EditText(this);
        dateInput.setHint("Select Event Date");
        dateInput.setFocusable(false);
        dateInput.setOnClickListener(v -> showDatePickerDialog(dateInput));
        layout.addView(dateInput);

        final EditText descInput = new EditText(this);
        descInput.setHint("Enter Event Description");
        descInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        layout.addView(descInput);

        builder.setView(layout);

        builder.setPositiveButton("Add", (dialog, which) -> {
            String name = nameInput.getText().toString();
            String date = dateInput.getText().toString();
            String desc = descInput.getText().toString();

            if (!name.isEmpty() && !date.isEmpty()) {
                JSONObject data = new JSONObject();
                try {
                    data.put("event_name", name);
                    data.put("event_date", date);
                    data.put("event_desc", desc);
                    data.put("user_id", loggedInUserId);
                } catch (Exception e) {
                    Toast.makeText(this, "JSON Error", Toast.LENGTH_SHORT).show();
                    return;
                }

                String url = BASE_URL + "/add_event";
                JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, url, data,
                        response -> {
                            Toast.makeText(this, "Event added", Toast.LENGTH_SHORT).show();
                            loadEventsFromBackend();
                        },
                        error -> Toast.makeText(this, "Add failed", Toast.LENGTH_SHORT).show()
                );
                requestQueue.add(request);
            } else {
                Toast.makeText(this, "Fields cannot be empty", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());
        builder.show();
    }

    // Delete event using Flask API
    private void deleteEvent(int position) {
        int eventId = events.get(position).getId();
        String url = BASE_URL + "/delete_event/" + eventId;
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.DELETE, url, null,
                response -> {
                    Toast.makeText(this, "Deleted", Toast.LENGTH_SHORT).show();
                    loadEventsFromBackend();
                },
                error -> Toast.makeText(this, "Delete failed", Toast.LENGTH_SHORT).show()
        );
        requestQueue.add(request);
    }

    // Filter displayed events
    private void filterEvents(String query) {
        if (query.isEmpty()) {
            events.clear();
            events.addAll(allEvents);
        } else {
            List<Event> filtered = new ArrayList<>();
            for (Event e : allEvents) {
                if (e.getName().toLowerCase().contains(query.toLowerCase()) ||
                        e.getDate().toLowerCase().contains(query.toLowerCase())) {
                    filtered.add(e);
                }
            }
            events.clear();
            events.addAll(filtered);
        }
        adapter.updateList(new ArrayList<>(events));
    }

    // Show date picker for date input
    private void showDatePickerDialog(EditText dateInput) {
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        new android.app.DatePickerDialog(this,
                (view, year1, month1, day1) -> {
                    String formattedDate = String.format("%04d-%02d-%02d", year1, month1 + 1, day1);
                    dateInput.setText(formattedDate);
                },
                year, month, day).show();
    }
}
