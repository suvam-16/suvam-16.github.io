package com.example.eventtracking;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
import android.app.AlertDialog;
import android.content.Context;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.os.Handler;


public class EventGridAdapter extends RecyclerView.Adapter<EventGridAdapter.ViewHolder> {

    private final List<Event> events;
    private final OnDeleteClickListener deleteClickListener;

    public interface OnDeleteClickListener {
        void onDeleteClick(int position);
    }

    public EventGridAdapter(List<Event> events, OnDeleteClickListener deleteClickListener) {
        this.events = events;
        this.deleteClickListener = deleteClickListener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_event_grid, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Event event = events.get(position);
        holder.eventTitle.setText(event.getName());
        holder.eventDetails.setText(event.getDate());
        holder.eventDescription.setText(event.getDescription());

        // On item click, show full description in an AlertDialog
        holder.itemView.setOnClickListener(v -> {
            // Ensure we're passing the correct context
            Context context = holder.itemView.getContext();

            // Create and show the AlertDialog
            AlertDialog.Builder builder = new AlertDialog.Builder(context);
            builder.setTitle(event.getName())  // Event name as the dialog title
                    .setMessage(event.getDescription())  // Full description as the message
                    .setPositiveButton("Close", (dialog, which) -> dialog.dismiss())  // Close button
                    .show();  // Show the dialog
        });

        // Apply the shrink and fade-out animation on delete click
        holder.deleteButton.setOnClickListener(v -> {
            // Trigger the shrink and fade-out animation
            Animation animation = AnimationUtils.loadAnimation(holder.itemView.getContext(), R.anim.shrink_fade_out);
            holder.itemView.startAnimation(animation);  // Start the animation

            // After the animation completes, delete the event
            new Handler().postDelayed(() -> deleteClickListener.onDeleteClick(position), 300);  // 300ms delay
        });
    }


    @Override
    public int getItemCount() {
        return events.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView eventTitle;
        TextView eventDetails;
        TextView eventDescription; // NEW: For event description
        ImageButton deleteButton;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            eventTitle = itemView.findViewById(R.id.event_title);
            eventDetails = itemView.findViewById(R.id.event_details);
            eventDescription = itemView.findViewById(R.id.event_description); // NEW: Reference to event description TextView
            deleteButton = itemView.findViewById(R.id.delete_button);
        }
    }
}
