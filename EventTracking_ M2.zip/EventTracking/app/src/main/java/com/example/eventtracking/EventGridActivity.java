package com.example.eventtracking;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class EventGridActivity extends AppCompatActivity {

    private List<Event> events; // List of events (filtered list)
    private List<Event> allEvents; // NEW: Master list to preserve all events for search reset
    private EventGridAdapter adapter; // Adapter for RecyclerView
    private DatabaseHelper dbHelper; // Database Helper

    private int loggedInUserId; // User ID of the logged-in user

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_grid);

        // Initialize DatabaseHelper
        dbHelper = new DatabaseHelper(this);

        // Retrieve logged-in user ID
        SharedPreferences sharedPreferences = getSharedPreferences("EventTrackingPrefs", MODE_PRIVATE);
        loggedInUserId = sharedPreferences.getInt("loggedInUserId", -1);

        if (loggedInUserId == -1) {
            Toast.makeText(this, "No logged-in user found. Please log in again.", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        // Initialize events lists
        events = new ArrayList<>();
        allEvents = new ArrayList<>(); // NEW: Master list for full search reset

        // Set up RecyclerView
        RecyclerView recyclerView = findViewById(R.id.event_grid_recycler);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 2)); // Grid with 2 columns
        adapter = new EventGridAdapter(events, this::deleteEvent);
        recyclerView.setAdapter(adapter);

        // Set up Spinner for sorting
        Spinner sortSpinner = findViewById(R.id.sort_spinner);
        ArrayAdapter<CharSequence> spinnerAdapter = ArrayAdapter.createFromResource(
                this, R.array.sort_options, android.R.layout.simple_spinner_item);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sortSpinner.setAdapter(spinnerAdapter);

        // Handle Spinner selection
        sortSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position == 0) {
                    loadEventsSortedByDate();
                } else if (position == 1) {
                    loadEventsSortedByName();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        // Set up search input for filtering
        EditText searchInput = findViewById(R.id.search_input);
        searchInput.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                filterEvents(s.toString().trim()); // trim whitespace
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        // FloatingActionButton for adding events
        FloatingActionButton addButton = findViewById(R.id.add_event_button);
        addButton.setOnClickListener(v -> showAddEventDialog());

        // FloatingActionButton for SMS notifications
        FloatingActionButton smsButton = findViewById(R.id.sms_button);
        smsButton.setOnClickListener(v -> {
            Intent intent = new Intent(EventGridActivity.this, SMSActivity.class);
            startActivity(intent);
        });
    }

    // Load events sorted by date
    private void loadEventsSortedByDate() {
        events.clear();
        allEvents.clear();
        Cursor cursor = dbHelper.getEventsSortedByDate(loggedInUserId);
        if (cursor != null) {
            try {
                while (cursor.moveToNext()) {
                    int id = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_EVENT_ID));
                    String name = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_EVENT_NAME));
                    String date = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_EVENT_DATE));
                    String desc = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_EVENT_DESC));
                    Event event = new Event(id, name, date, desc);
                    events.add(event);
                    allEvents.add(event);
                }
            } finally {
                cursor.close();
            }
        }
        adapter.updateList(new ArrayList<>(events)); // Set full list
    }

    // Load events sorted by name
    private void loadEventsSortedByName() {
        events.clear();
        allEvents.clear();
        Cursor cursor = dbHelper.getEventsSortedByName(loggedInUserId);
        if (cursor != null) {
            try {
                while (cursor.moveToNext()) {
                    int id = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_EVENT_ID));
                    String name = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_EVENT_NAME));
                    String date = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_EVENT_DATE));
                    String desc = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_EVENT_DESC));
                    Event event = new Event(id, name, date, desc);
                    events.add(event);
                    allEvents.add(event);
                }
            } finally {
                cursor.close();
            }
        }
        adapter.updateList(new ArrayList<>(events)); // Set full list
    }

    // Filter events based on search input
    private void filterEvents(String query) {
        if (query.isEmpty()) {
            //Reset to full list if search is cleared
            events.clear();
            events.addAll(allEvents);
            adapter.updateList(new ArrayList<>(events));
            return;
        }

        List<Event> filtered = new ArrayList<>();
        for (Event event : allEvents) {
            if (event.getName().toLowerCase().contains(query.toLowerCase()) ||
                    event.getDate().toLowerCase().contains(query.toLowerCase())) {
                filtered.add(event);
            }
        }

        events.clear();
        events.addAll(filtered);
        adapter.updateList(filtered);
    }

    // Show dialog to add a new event
    private void showAddEventDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Add New Event");

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);

        final EditText nameInput = new EditText(this);
        nameInput.setHint("Enter Event Name");
        layout.addView(nameInput);

        final EditText dateInput = new EditText(this);
        dateInput.setHint("Select Event Date");
        dateInput.setFocusable(false);
        dateInput.setOnClickListener(v -> showDatePickerDialog(dateInput));
        layout.addView(dateInput);

        final EditText descInput = new EditText(this);
        descInput.setHint("Enter Event Description");
        descInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        layout.addView(descInput);

        builder.setView(layout);

        builder.setPositiveButton("Add", (dialog, which) -> {
            String name = nameInput.getText().toString();
            String date = dateInput.getText().toString();
            String desc = descInput.getText().toString();
            if (!name.isEmpty() && !date.isEmpty()) {
                long eventId = dbHelper.addEvent(name, date, desc, loggedInUserId);
                if (eventId != -1) {
                    Event newEvent = new Event((int) eventId, name, date, desc);
                    events.add(newEvent);
                    allEvents.add(newEvent); //Add to full list too
                    adapter.updateList(new ArrayList<>(events));
                } else {
                    Toast.makeText(this, "Failed to add event. Try again.", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, "Fields cannot be empty", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());
        builder.show();
    }

    // Show date picker dialog with proper formatting // assist sorting
    private void showDatePickerDialog(EditText dateInput) {
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        new android.app.DatePickerDialog(this,
                (view, year1, month1, day1) -> {
                    String formattedDate = String.format("%04d-%02d-%02d", year1, month1 + 1, day1);
                    dateInput.setText(formattedDate);
                },
                year, month, day).show();
    }

    // Delete event from the database and update the grid
    private void deleteEvent(int position) {
        Event event = events.get(position);
        int rowsAffected = dbHelper.deleteEvent(event.getId());
        if (rowsAffected > 0) {
            events.remove(position);
            allEvents.removeIf(e -> e.getId() == event.getId()); //Remove from both lists
            adapter.updateList(new ArrayList<>(events));
        } else {
            Toast.makeText(this, "Failed to delete event. Try again.", Toast.LENGTH_SHORT).show();
        }
    }
}
