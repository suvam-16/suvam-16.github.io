package com.example.eventtracking;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.app.AlertDialog;
import android.content.Context;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.os.Handler;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class EventGridAdapter extends RecyclerView.Adapter<EventGridAdapter.ViewHolder> {

    private List<Event> events; // Now mutable to support filtering
    private final OnDeleteClickListener deleteClickListener;

    public interface OnDeleteClickListener {
        void onDeleteClick(int position);
    }

    public EventGridAdapter(List<Event> events, OnDeleteClickListener deleteClickListener) {
        this.events = events;
        this.deleteClickListener = deleteClickListener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_event_grid, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Event event = events.get(position);
        holder.eventTitle.setText(event.getName());
        holder.eventDetails.setText(event.getDate());
        holder.eventDescription.setText(event.getDescription());

        // On item click, show full description in an AlertDialog
        holder.itemView.setOnClickListener(v -> {
            Context context = holder.itemView.getContext();
            AlertDialog.Builder builder = new AlertDialog.Builder(context);
            builder.setTitle(event.getName())
                    .setMessage(event.getDescription())
                    .setPositiveButton("Close", (dialog, which) -> dialog.dismiss())
                    .show();
        });

        // Apply the shrink and fade-out animation on delete click
        holder.deleteButton.setOnClickListener(v -> {
            Animation animation = AnimationUtils.loadAnimation(holder.itemView.getContext(), R.anim.shrink_fade_out);
            holder.itemView.startAnimation(animation);
            new Handler().postDelayed(() -> deleteClickListener.onDeleteClick(position), 300);
        });
    }

    @Override
    public int getItemCount() {
        return events.size();
    }

    // NEW: Update the event list dynamically (for search filtering)
    public void updateList(List<Event> updatedEvents) {
        events.clear();
        events.addAll(updatedEvents);
        notifyDataSetChanged();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView eventTitle;
        TextView eventDetails;
        TextView eventDescription;
        ImageButton deleteButton;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            eventTitle = itemView.findViewById(R.id.event_title);
            eventDetails = itemView.findViewById(R.id.event_details);
            eventDescription = itemView.findViewById(R.id.event_description);
            deleteButton = itemView.findViewById(R.id.delete_button);
        }
    }
}
